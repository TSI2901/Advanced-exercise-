﻿namespace DirectoryTraversal
{
    using System;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Collections.Generic;

    public class DirectoryTraversal
    {
        static void Main()
        {
            string path = Console.ReadLine();
            string reportFileName = @"\report.txt";

            string reportContent = TraverseDirectory(path);
            Console.WriteLine(reportContent);

            WriteReportToDesktop(reportContent, reportFileName);
        }

        public static string TraverseDirectory(string inputFolderPath)
        {
            string[] files = Directory.GetFiles(inputFolderPath);
            Dictionary<string, List<FileInfo>> dic = new Dictionary<string, List<FileInfo>>();
            foreach (var file in files)
            {
                FileInfo fileinfo = new FileInfo(file);
                var extention = fileinfo.Extension;

                if (!dic.ContainsKey(extention))
                {
                    dic.Add(extention, new List<FileInfo>());
                }
                dic[extention].Add(fileinfo);
            }
            var sb = new StringBuilder();
            foreach (var item in dic.OrderByDescending(entry => entry.Value.Count).ThenBy(entry => entry.Key))
            {
                string extention = item.Key;
                sb.AppendLine(extention);
                //Console.WriteLine(extention);
                List<FileInfo> list = item.Value;
                list.OrderByDescending(file => file.Length);
                foreach (FileInfo file in list)
                {
                    sb.AppendLine($"--{file.Name} - {file.Length / 1024:F3}kb");
                    //Console.WriteLine($"--{file.Name} - {file.Length / 1024:F3}kb");
                }
            }
            return sb.ToString();
        }

        public static void WriteReportToDesktop(string textContent, string reportFileName)
        {
            string pathReport = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + reportFileName;
            File.WriteAllText(pathReport, textContent);
        }
    }
}
