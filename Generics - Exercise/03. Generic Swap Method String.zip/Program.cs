﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace _03._Generic_Swap_Method_String
{
    public class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            var list = new List<string>();
            for (int i = 0; i < n; i++)
            {
                var input = Console.ReadLine();
                list.Add(input);
            }
            var swap = new Swap<string>(list);
            var indexes = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
            swap.Swap2(list,indexes[0], indexes[1]);
            Console.WriteLine(swap);
        }
        
    }
}
