﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04._Generic_Swap_Method_Integer
{
    public class Swap<T>
    {
        public List<T> List { get; set; }
        public T Element { get; set; }
        public Swap(T element)
        {
            Element = element;
        }
        public Swap(List<T> list)
        {
            List = list;
        }
        public void Swap2(List<T> elements, int index1, int index2)
        {
            T element1 = elements[index1];
            elements[index1] = elements[index2];
            elements[index2] = element1;
        }

        public override string ToString()
        {
            var sb = new StringBuilder();
            foreach (var element in List)
            {
                sb.AppendLine($"{element.GetType()}: {element}");
            }
            return sb.ToString().TrimEnd();
        }
    }
}
