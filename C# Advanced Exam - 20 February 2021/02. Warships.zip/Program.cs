﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace _02._Warships
{
    internal class Program
    {
        private static char[,] matrix;
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            matrix = new char[n,n];
            List<int> player1row = new List<int>();
            List<int> player1coll = new List<int>();
            List<int> player2row = new List<int>();
            List<int> player2coll = new List<int>();
            int player1Ships = 0;
            int player1ShipsAll = 0;
            int player2Ships = 0;
            int player2ShipsAll = 0;
            string[] input = Console.ReadLine().Split(',');
            for (int i = 0; i < input.Length; i++)
            {
                if (i % 2==0)
                {
                    int row = int.Parse(input[i].Split(' ')[0]);
                    int coll = int.Parse(input[i].Split(' ')[1]);
                    player1row.Add(row);
                    player1coll.Add(coll);
                }
                else
                {
                    int row = int.Parse(input[i].Split(' ')[0]);
                    int coll = int.Parse(input[i].Split(' ')[1]);
                    player2row.Add(row);
                    player2coll.Add(coll);
                }
            }
            for (int i = 0; i < n; i++)
            {
                char[] line = Console.ReadLine().Split(' ').Select(char.Parse).ToArray();
                for (int j = 0; j < line.Length; j++)
                {
                    matrix[i,j] = line[j];
                    if (matrix[i,j] == '<')
                    {
                        player1Ships++;
                        player1ShipsAll++;
                    }
                    else if (matrix[i,j] == '>')
                    {
                        player2Ships++;
                        player2ShipsAll++;
                    }
                }
            }
            for (int i = 0; i < input.Length; i++)
            {
                int currRow1 = 0;
                int currColl1 = 0;
                int currRow2 = 0;
                int currColl2 = 0;
                if (player1row.Count > i)
                {
                    currRow1 = player1row[i];
                    currColl1 = player1coll[i];
                    if (IsInside(currRow1, currColl1))
                    {
                        if (matrix[currRow1, currColl1] == '>')
                        {
                            matrix[currRow1, currColl1] = 'X';
                            player2Ships--;
                        }
                        else if (matrix[currRow1, currColl1] == '#')
                        {
                            if (IsInside(currRow1 - 1, currColl1))
                            {
                                if (matrix[currRow1 - 1, currColl1] == '<')
                                {
                                    player1Ships--;
                                }
                                else if (matrix[currRow1 - 1, currColl1] == '>')
                                {
                                    player2Ships--;
                                }
                                matrix[currRow1 - 1, currColl1] = 'X';
                            }
                            if (IsInside(currRow1 + 1, currColl1))
                            {
                                if (matrix[currRow1 + 1, currColl1] == '<')
                                {
                                    player1Ships--;
                                }
                                else if (matrix[currRow1 + 1, currColl1] == '>')
                                {
                                    player2Ships--;
                                }
                                matrix[currRow1 + 1, currColl1] = 'X';
                            }
                            if (IsInside(currRow1, currColl1 - 1))
                            {
                                if (matrix[currRow1, currColl1 - 1] == '<')
                                {
                                    player1Ships--;
                                }
                                else if (matrix[currRow1, currColl1 - 1] == '>')
                                {
                                    player2Ships--;
                                }
                                matrix[currRow1, currColl1 - 1] = 'X';
                            }
                            if (IsInside(currRow1, currColl1 + 1))
                            {
                                if (matrix[currRow1, currColl1 + 1] == '<')
                                {
                                    player1Ships--;
                                }
                                else if (matrix[currRow1, currColl1 + 1] == '>')
                                {
                                    player2Ships--;
                                }
                                matrix[currRow1, currColl1 + 1] = 'X';
                            }
                            if (IsInside(currRow1 - 1, currColl1 - 1))
                            {
                                if (matrix[currRow1 - 1, currColl1 - 1] == '<')
                                {
                                    player1Ships--;
                                }
                                else if (matrix[currRow1 - 1, currColl1 - 1] == '>')
                                {
                                    player2Ships--;
                                }
                                matrix[currRow1 - 1, currColl1 - 1] = 'X';
                            }
                            if (IsInside(currRow1 - 1, currColl1 + 1))
                            {
                                if (matrix[currRow1 - 1, currColl1 + 1] == '<')
                                {
                                    player1Ships--;
                                }
                                else if (matrix[currRow1 - 1, currColl1 + 1] == '>')
                                {
                                    player2Ships--;
                                }
                                matrix[currRow1 - 1, currColl1 + 1] = 'X';
                            }
                            if (IsInside(currRow1 + 1, currColl1 - 1))
                            {
                                if (matrix[currRow1 + 1, currColl1 - 1] == '<')
                                {
                                    player1Ships--;
                                }
                                else if (matrix[currRow1 + 1, currColl1 - 1] == '>')
                                {
                                    player2Ships--;
                                }
                                matrix[currRow1 + 1, currColl1 - 1] = 'X';
                            }
                            if (IsInside(currRow1 + 1, currColl1 + 1))
                            {
                                if (matrix[currRow1 + 1, currColl1 + 1] == '<')
                                {
                                    player1Ships--;
                                }
                                else if (matrix[currRow1 + 1, currColl1 + 1] == '>')
                                {
                                    player2Ships--;
                                }
                                matrix[currRow1 + 1, currColl1 + 1] = 'X';
                            }
                        }
                    }
                    if (player2Ships == 0)
                    {
                        break;
                    }



                    
                }
                if (player2row.Count > i)
                {
                    currRow2 = player2row[i];
                    currColl2 = player2coll[i];
                    if (IsInside(currRow2, currColl2))
                    {
                        if (matrix[currRow2, currColl2] == '<')
                        {
                            matrix[currRow2, currColl2] = 'X';
                            player1Ships--;
                        }
                        else if (matrix[currRow2, currColl2] == '#')
                        {
                            if (IsInside(currRow2 - 1, currColl2))
                            {
                                if (matrix[currRow2 - 1, currColl2] == '<')
                                {
                                    player1Ships--;
                                }
                                else if (matrix[currRow2 - 1, currColl2] == '>')
                                {
                                    player2Ships--;
                                }
                                matrix[currRow2 - 1, currColl2] = 'X';
                            }
                            if (IsInside(currRow2 + 1, currColl2))
                            {
                                if (matrix[currRow2 + 1, currColl2] == '<')
                                {
                                    player1Ships--;
                                }
                                else if (matrix[currRow2 + 1, currColl2] == '>')
                                {
                                    player2Ships--;
                                }
                                matrix[currRow2 + 1, currColl2] = 'X';
                            }
                            if (IsInside(currRow2, currColl2 - 1))
                            {
                                if (matrix[currRow2, currColl2 - 1] == '<')
                                {
                                    player1Ships--;
                                }
                                else if (matrix[currRow2, currColl2 - 1] == '>')
                                {
                                    player2Ships--;
                                }
                                matrix[currRow2, currColl2 - 1] = 'X';
                            }
                            if (IsInside(currRow2, currColl2 + 1))
                            {
                                if (matrix[currRow2, currColl2 + 1] == '<')
                                {
                                    player1Ships--;
                                }
                                else if (matrix[currRow2, currColl2 + 1] == '>')
                                {
                                    player2Ships--;
                                }
                                matrix[currRow2, currColl2 + 1] = 'X';
                            }
                            if (IsInside(currRow2 - 1, currColl2 - 1))
                            {
                                if (matrix[currRow2 - 1, currColl2 - 1] == '<')
                                {
                                    player1Ships--;
                                }
                                else if (matrix[currRow2 - 1, currColl2 - 1] == '>')
                                {
                                    player2Ships--;
                                }
                                matrix[currRow2 - 1, currColl2 - 1] = 'X';
                            }
                            if (IsInside(currRow2 - 1, currColl2 + 1))
                            {
                                if (matrix[currRow2 - 1, currColl2 + 1] == '<')
                                {
                                    player1Ships--;
                                }
                                else if (matrix[currRow2 - 1, currColl2 + 1] == '>')
                                {
                                    player2Ships--;
                                }
                                matrix[currRow2 - 1, currColl2 + 1] = 'X';
                            }
                            if (IsInside(currRow2 + 1, currColl2 - 1))
                            {
                                if (matrix[currRow2 + 1, currColl2 - 1] == '<')
                                {
                                    player1Ships--;
                                }
                                else if (matrix[currRow2 + 1, currColl2 - 1] == '>')
                                {
                                    player2Ships--;
                                }
                                matrix[currRow2 + 1, currColl2 - 1] = 'X';
                            }
                            if (IsInside(currRow2 + 1, currColl2 + 1))
                            {
                                if (matrix[currRow2 + 1, currColl2 + 1] == '<')
                                {
                                    player1Ships--;
                                }
                                else if (matrix[currRow2 + 1, currColl2 + 1] == '>')
                                {
                                    player2Ships--;
                                }
                                matrix[currRow2 + 1, currColl2 + 1] = 'X';
                            }
                        }
                    }
                    if (player1Ships == 0)
                    {
                        break;
                    }
                }
            }
            if (player2Ships == 0)
            {
                Console.WriteLine($"Player One has won the game! {(player1ShipsAll - player1Ships) + player2ShipsAll} ships have been sunk in the battle.");
            }
            else if (player1Ships == 0)
            {
                Console.WriteLine($"Player Two has won the game! {(player2ShipsAll - player2Ships) + player1ShipsAll} ships have been sunk in the battle.");
            }
            else
            {
                Console.WriteLine($"It's a draw! Player One has {player1Ships} left. Player Two has {player2Ships} left.");
            }
        }
        static bool IsInside(int row, int coll)
        {
            return row >= 0 && coll >= 0 
                && row < matrix.GetLength(0) && coll < matrix.GetLength(1);
        }
    }
}
