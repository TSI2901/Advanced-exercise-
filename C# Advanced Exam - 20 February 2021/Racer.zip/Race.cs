﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TheRace
{
    public class Race
    {
        public List<Racer> data { get; set; }
        public string Name { get; set; }
        public int  Capacity { get; set; }
        public Race(string name, int capacity)
        {
            Name = name;
            Capacity = capacity;
            data = new List<Racer>();
        }
        public void Add(Racer Racer)
        {
            if (data.Count < Capacity)
            {
                data.Add(Racer);
            }
        }
        public bool Remove(string name)
        {
            bool removed = false;
            if (data.Count > 0)
            {
                foreach (var item in data)
                {
                    if (item.Name == name)
                    {
                        data.Remove(item);
                        removed = true;
                        break;
                    }
                }
            }
            return removed;
        }
        public Racer GetOldestRacer()
        {
            Racer oldestRacer = null;
            int oldestAge = 0;
            if (data.Count > 0)
            {
                foreach (var item in data)
                {
                    if (item.Age > oldestAge)
                    {
                        oldestRacer = item;
                        oldestAge = item.Age;
                    }
                }
            }
            return oldestRacer;
        }
        public Racer GetRacer(string name)
        {
            Racer searchdRacer = null;
            if (data.Count > 0)
            {
                foreach (var item in data)
                {
                    if (item.Name == name)
                    {
                        searchdRacer = item;
                    }
                }
            }
            return searchdRacer;
        }
        public Racer GetFastestRacer()
        {
            Racer fastestRacer = null;
            int fastestSpeed = 0;
            if (data.Count > 0)
            {
                foreach (var item in data)
                {
                    if (item.Car.Speed > fastestSpeed)
                    {
                        fastestRacer = item;
                        fastestSpeed = item.Car.Speed;
                    }
                }
            }
            return fastestRacer;
        }
        public int Count 
        {
            get { return data.Count; }
        }
        public string Report()
        {
            return $"Racers participating at {this.Name}:" + Environment.NewLine
                + $"{String.Join(Environment.NewLine, this.data)}";
        }
    }
}
