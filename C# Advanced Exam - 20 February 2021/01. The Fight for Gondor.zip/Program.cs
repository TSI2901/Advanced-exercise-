﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace TheFightForGondor
{
    class Program
    {
        static void Main(string[] args)
        {
            int waves = int.Parse(Console.ReadLine());

            Queue<int> Plates = new Queue<int>(Console.ReadLine()
                .Split(new[] { " " }, StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse).ToArray());

            Stack<int> warriorOrcsLeft = new Stack<int>();
            bool isTheDefenceOfGondorDestroyed = false;

            for (int i = 1; i <= waves; i++)
            {
                Stack<int> currOrcs = new Stack<int>(Console.ReadLine()
                    .Split(new[] { " " }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(int.Parse).ToArray());

                if (i % 3 == 0)
                {
                    int additionalPlate = int.Parse(Console.ReadLine());
                    Plates.Enqueue(additionalPlate);
                }

                while (currOrcs.Count != 0 && Plates.Count != 0)
                {
                    if (currOrcs.Peek() > Plates.Peek())
                    {
                        currOrcs.Push(currOrcs.Pop() - Plates.Dequeue());
                    }
                    else if (Plates.Peek() > currOrcs.Peek())
                    {
                        Queue<int> platesAfterAttack = new Queue<int>();

                        platesAfterAttack.Enqueue(Plates.Dequeue() - currOrcs.Pop());

                        for (int j = 0; j < Plates.Count; j++)
                        {
                            platesAfterAttack.Enqueue(Plates.ElementAt(j));
                        }

                        Plates = platesAfterAttack;
                    }
                    else
                    {
                        Plates.Dequeue();
                        currOrcs.Pop();
                    }

                    if (Plates.Count == 0)
                    {
                        isTheDefenceOfGondorDestroyed = true;
                        warriorOrcsLeft = currOrcs;
                        break;
                    }
                }
            }

            if (isTheDefenceOfGondorDestroyed)
            {
                Console.WriteLine("The orcs successfully destroyed the Gondor's defense.");
                Console.WriteLine($"Orcs left: {string.Join(", ", warriorOrcsLeft)}");
            }
            else
            {
                Console.WriteLine("The people successfully repulsed the orc's attack.");
                Console.WriteLine($"Plates left: {string.Join(", ", Plates)}");
            }
        }
    }
}