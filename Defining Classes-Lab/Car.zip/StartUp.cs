﻿using CarManufacturer;
using System;
using System.Linq;


namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Car car = new Car();
            car.Make = "BMW";
            car.Name = "X6";
            car.Year = 2006;
            Console.WriteLine($"Make {car.Make}\nModel: {car.Name}\nYear {car.Year}");
        }
    }
}
