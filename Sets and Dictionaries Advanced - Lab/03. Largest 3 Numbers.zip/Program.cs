﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace _03._Largest_3_Numbers
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var nums = Console.ReadLine().Split(' ').Select(double.Parse).OrderByDescending(x => x).ToList().Take(3);
            Console.WriteLine(String.Join(" ", nums));
        }
    }
}
