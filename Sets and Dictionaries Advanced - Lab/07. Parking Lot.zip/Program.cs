﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace _07._Parking_Lot
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var cars = new HashSet<string>();
            while (true)
            {
                var command = Console.ReadLine().Split(", ");
                if (command[0] == "END")
                {
                    break;
                }
                if (command[0] == "IN")
                {
                    cars.Add(command[1]);
                }
                if (command[0] == "OUT")
                {
                    cars.Remove(command[1]);
                }
            }
            if (!cars.Any())
            {
                Console.WriteLine("Parking Lot is Empty");
            }
            else
            {
                foreach (var item in cars)
                {
                    Console.WriteLine(item);
                }
            }
        }
    }
}
