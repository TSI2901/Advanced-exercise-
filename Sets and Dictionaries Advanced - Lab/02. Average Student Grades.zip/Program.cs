﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace _02._Average_Student_Grades
{
    
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            var dic = new Dictionary<string, List<double>>();
            
            for (int i = 0; i < n; i++)
            {
                var student = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries).ToList();
                if (dic.ContainsKey(student[0]))
                {
                    dic[student[0]].Add(double.Parse(student[1]));
                }
                else
                {
                    List<double> list = new List<double>();
                    list.Add(double.Parse(student[1]));
                    dic.Add(student[0], list);
                }
            }
            foreach (var item in dic)
            {
                
                Console.Write($"{ item.Key} -> ");
                foreach (var item2 in item.Value)
                {
                    Console.Write($"{item2:f2} ");
                }
                Console.Write($"(avg: {item.Value.Average():f2})");
                Console.WriteLine();
            }
        }
    }
}
