﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace _04._Product_Shop
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SortedDictionary<string, Dictionary<string,double>> dic = new SortedDictionary<string, Dictionary<string,double>>();
            while (true)
            {
                var command = Console.ReadLine().Split(", ").ToList();
                string shop = command[0];
                
                if (command[0] == "Revision")
                {
                    break;
                }
                string product = command[1];
                double price = double.Parse(command[2]);
                if (!(dic.ContainsKey(shop)))
                {
                    dic.Add(shop, new Dictionary<string, double>());
                    dic[shop][product] = price;
                }
                else
                {
                    dic[shop][product] = price;
                }
            }
            foreach (var item in dic)
            {
                Console.WriteLine($"{item.Key}->");
                foreach (var product in item.Value)
                {
                    Console.WriteLine($"Product: {product.Key}, Price: {product.Value}");
                }
            }
        }
    }
}
