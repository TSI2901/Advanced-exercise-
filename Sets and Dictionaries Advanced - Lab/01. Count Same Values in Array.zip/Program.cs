﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace _01._Count_Same_Values_in_Array
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var dic = new Dictionary<double, int>();
            var nums = Console.ReadLine().Split(' ').Select(double.Parse).ToArray();
            foreach (var num in nums)
            {
                if (dic.ContainsKey(num))
                {
                    dic[num]++;
                }
                else
                {
                    dic[num] = 1;
                }
            }
            foreach (var num in dic)
            {
                Console.WriteLine($"{num.Key} - {num.Value} times");
            }
        }
    }
}
