﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Renovators
{
    public class Catalog
    {
        public List<Renovator> renovators { get; set; }
        public string Name { get; set; }
        public int NeededRenovators { get; set; }
        public string Project { get; set; }
        public Catalog(string name,int neededRenovators, string project)
        {
            Name = name;
            NeededRenovators = neededRenovators;
            Project = project;
            renovators = new List<Renovator>();
        }
        public int Count 
        {
            get { return renovators.Count; }
        }
        public string AddRenovator(Renovator renovator)
        {
            if (renovators.Count < NeededRenovators)
            {
                if (String.IsNullOrEmpty(renovator.Name) || String.IsNullOrEmpty(renovator.Type))
                {
                    return "Invalid renovator's information.";
                }
                else if (renovator.Rate > 350)
                {
                    return "Invalid renovator's rate.";
                }
                else
                {
                    renovators.Add(renovator);
                }
            }
            else
            {
                return "Renovators are no more needed.";
            }
            return $"Successfully added {renovator.Name} to the catalog.";
        }
        public bool RemoveRenovator(string name)
        {
            
            bool isExist = false;
            if (renovators.Count > 0)
            {
                foreach (var item in renovators)
                {
                    if (item.Name == name)
                    {
                        renovators.Remove(item);
                        isExist = true;
                        break;
                    }
                }
            }
            return isExist;
        }
        public int RemoveRenovatorBySpecialty(string type)
        {
            int count = 0;
            List<Renovator> searchedRenovators = new List<Renovator>();
            if (renovators.Count > 0)
            {
                foreach (var item in renovators)
                {
                    if (item.Type == type)
                    {
                        count++;
                        searchedRenovators.Add(item);
                    }
                }
                foreach (var item in searchedRenovators)
                {
                    renovators.Remove(item);
                }
            }
            return count;
        }
        public Renovator HireRenovator(string name)
        {
            Renovator searchedrenovator = null;
            if (renovators.Count > 0)
            {
                foreach (var item in renovators)
                {
                    if (item.Name == name)
                    {
                        item.Hired = true;
                        searchedrenovator = item;
                    }
                }
            }
            return searchedrenovator;
        }
        public List<Renovator> PayRenovators(int days)
        {
            
            return renovators.Where(x => x.Days >= days).ToList();
        }
        public string Report()
        {
            List<Renovator> searchedrenovators = new List<Renovator>();
            if (renovators.Count > 0)
            {
                foreach (var item in renovators)
                {
                    if (item.Hired == false)
                    {
                        searchedrenovators.Add(item);
                    }
                }
            }
            return $"Renovators available for Project {Project}:" + Environment.NewLine + String.Join(Environment.NewLine, searchedrenovators);
        }
    }
}
