﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace _01._Tiles_Master
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Stack<int> whiteTiles = new Stack<int>(Console.ReadLine().Split(' ').Select(int.Parse));
            Queue<int> greyTiles = new Queue<int>(Console.ReadLine().Split(' ').Select(int.Parse));
            SortedDictionary<string, int> dic = new SortedDictionary<string, int>();
            while (whiteTiles.Any() && greyTiles.Any())
            {
                int currWhite = whiteTiles.Peek();
                int currGrey = greyTiles.Peek();
                if (currWhite == currGrey)
                {
                    int sum = currWhite + currGrey;
                    if (sum == 40)
                    {
                        if (dic.ContainsKey("Sink"))
                        {
                            dic["Sink"]++;
                        }
                        else
                        {
                            dic.Add("Sink", 1);
                        }
                    }
                    else if (sum == 50)
                    {
                        if (dic.ContainsKey("Oven"))
                        {
                            dic["Oven"]++;
                        }
                        else
                        {
                            dic.Add("Oven", 1);
                        }
                    }
                    else if (sum == 60)
                    {
                        if (dic.ContainsKey("Countertop"))
                        {
                            dic["Countertop"]++;
                        }
                        else
                        {
                            dic.Add("Countertop", 1);
                        }
                    }
                    else if (sum == 70)
                    {
                        if (dic.ContainsKey("Wall"))
                        {
                            dic["Wall"]++;
                        }
                        else
                        {
                            dic.Add("Wall", 1);
                        }
                    }
                    else
                    {
                        if (dic.ContainsKey("Floor"))
                        {
                            dic["Floor"]++;
                        }
                        else
                        {
                            dic.Add("Floor", 1);
                        }
                    }
                    whiteTiles.Pop();
                    greyTiles.Dequeue();
                }
                else
                {
                    whiteTiles.Pop();
                    greyTiles.Dequeue();
                    whiteTiles.Push(currWhite / 2);
                    greyTiles.Enqueue(currGrey);
                }
            }
            if (whiteTiles.Count > 0)
            {
                Console.WriteLine($"White tiles left: {String.Join(", ",whiteTiles)}");
            }
            else
            {
                Console.WriteLine("White tiles left: none");
            }
            if (greyTiles.Count > 0)
            {
                Console.WriteLine($"Grey tiles left: {String.Join(", ", greyTiles)}");
            }
            else
            {
                Console.WriteLine("Grey tiles left: none");
            }
            foreach (var item in dic.OrderByDescending(x => x.Value))
            {
                Console.WriteLine($"{item.Key}: {item.Value}");
            }
        }
    }
}
