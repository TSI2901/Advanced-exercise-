﻿using System;

namespace _02._Wall_Destroyer
{
    internal class Program
    {
        private static char[,] matrix;
        private static int Vrows;
        private static int Vcolls;
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            matrix = new char[n,n];
            int holesCounter = 1;
            int hitRodCounter = 0;
            bool Iselectroshoted = false;
            for (int i = 0; i < n; i++)
            {
                string input = Console.ReadLine();
                for (int j = 0; j < input.Length; j++)
                {
                    matrix[i,j] = input[j];
                    if (matrix[i,j] == 'V')
                    {
                        Vrows = i;
                        Vcolls = j;
                    }
                }
            }
            while (true)
            {
                string cmd = Console.ReadLine();
                if (cmd == "End")
                {
                    break;
                }
                if (cmd == "up")
                {
                    if (IsInside(Vrows -1,Vcolls))
                    {
                        if (matrix[Vrows - 1, Vcolls] == 'R')
                        {
                            Console.WriteLine("Vanko hit a rod!");
                            hitRodCounter++;
                        }
                        else if (matrix[Vrows - 1, Vcolls] == 'C')
                        {
                            matrix[Vrows, Vcolls] = '*';
                            holesCounter++;
                            matrix[Vrows - 1, Vcolls] = 'E';
                            Iselectroshoted = true;
                            break;
                        }
                        else if (matrix[Vrows - 1, Vcolls] == '*')
                        {
                            matrix[Vrows - 1, Vcolls] = 'V';
                            matrix[Vrows, Vcolls] = '*';
                            Vrows--;
                            Console.WriteLine($"The wall is already destroyed at position [{Vrows}, {Vcolls}]!");
                        }
                        else
                        {
                            matrix[Vrows, Vcolls] = '*';
                            holesCounter++;
                            Vrows--;
                            matrix[Vrows, Vcolls] = 'V';
                        }
                    }
                }
                else if (cmd == "down")
                {
                    if (IsInside(Vrows + 1, Vcolls))
                    {
                        if (matrix[Vrows + 1, Vcolls] == 'R')
                        {
                            Console.WriteLine("Vanko hit a rod!");
                            hitRodCounter++;
                        }
                        else if (matrix[Vrows + 1, Vcolls] == 'C')
                        {
                            matrix[Vrows, Vcolls] = '*';
                            holesCounter++;
                            matrix[Vrows + 1, Vcolls] = 'E';
                            Iselectroshoted = true;
                            break;

                        }
                        else if (matrix[Vrows + 1, Vcolls] == '*')
                        {
                            matrix[Vrows + 1, Vcolls] = 'V';
                            matrix[Vrows, Vcolls] = '*';
                            Vrows++;
                            Console.WriteLine($"The wall is already destroyed at position [{Vrows}, {Vcolls}]!");
                        }
                        else
                        {
                            matrix[Vrows, Vcolls] = '*';
                            holesCounter++;
                            Vrows++;
                            matrix[Vrows, Vcolls] = 'V';
                        }
                    }
                }
                else if (cmd == "left")
                {
                    if (IsInside(Vrows , Vcolls - 1))
                    {
                        if (matrix[Vrows, Vcolls - 1] == 'R')
                        {
                            Console.WriteLine("Vanko hit a rod!");
                            hitRodCounter++;
                        }
                        else if (matrix[Vrows , Vcolls - 1] == 'C')
                        {
                            matrix[Vrows, Vcolls] = '*';
                            holesCounter++;
                            matrix[Vrows , Vcolls - 1] = 'E';
                            Iselectroshoted = true;
                            break;

                        }
                        else if (matrix[Vrows , Vcolls - 1] == '*')
                        {
                            matrix[Vrows , Vcolls - 1] = 'V';
                            matrix[Vrows, Vcolls] = '*';
                            Vcolls--;
                            Console.WriteLine($"The wall is already destroyed at position [{Vrows}, {Vcolls}]!");
                        }
                        else
                        {
                            matrix[Vrows, Vcolls] = '*';
                            holesCounter++;
                            Vcolls--;
                            matrix[Vrows, Vcolls] = 'V';
                        }
                    }
                }
                else if (cmd == "right")
                {
                    if (IsInside(Vrows , Vcolls + 1))
                    {
                        if (matrix[Vrows , Vcolls + 1] == 'R')
                        {
                            Console.WriteLine("Vanko hit a rod!");
                            hitRodCounter++;
                        }
                        else if (matrix[Vrows , Vcolls + 1] == 'C')
                        {
                            matrix[Vrows, Vcolls] = '*';
                            holesCounter++;
                            matrix[Vrows , Vcolls + 1] = 'E';
                            Iselectroshoted = true;
                            break;

                        }
                        else if (matrix[Vrows , Vcolls + 1] == '*')
                        {
                            matrix[Vrows , Vcolls + 1] = 'V';
                            matrix[Vrows, Vcolls] = '*';
                            Vcolls++;
                            Console.WriteLine($"The wall is already destroyed at position [{Vrows}, {Vcolls}]!");
                        }
                        else
                        {
                            matrix[Vrows, Vcolls] = '*';
                            holesCounter++;
                            Vcolls++;
                            matrix[Vrows, Vcolls] = 'V';
                        }
                    }
                }
            }
            if (Iselectroshoted)
            {
                Console.WriteLine($"Vanko got electrocuted, but he managed to make {holesCounter} hole(s).");
            }
            else
            {
                Console.WriteLine($"Vanko managed to make {holesCounter} hole(s) and he hit only {hitRodCounter} rod(s).");
            }
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    Console.Write(matrix[i,j]);
                }
                Console.WriteLine();
            }
        }
        static bool IsInside(int row,int coll)
        {
            return row >= 0 && coll >= 0
                && row < matrix.GetLength(0) && coll < matrix.GetLength(1);
        }
    }
}
