﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace _01._Bakery_Shop
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string,int> dic = new Dictionary<string, int>();
            Queue<double> water = new Queue<double>(Console.ReadLine().Split(' ').Select(double.Parse));
            Stack<double> flour = new Stack<double>(Console.ReadLine().Split(' ').Select(double.Parse));
            while (water.Any() && flour.Any())
            {
                double currWater = water.Peek();
                double currFlour = flour.Peek();
                if (MuffinMix(currWater,currFlour))
                {

                }
                else if (true)
                {

                }
                else if (true)
                {

                }
                else if (true)
                {

                }
            }
            
        }
        static double[] GetPercent(double water, double flour)
        {
            double[] arr = new double[2];
            arr[0] = (water * 100) / (water + flour);
            arr[1] = (flour * 100) / (water + flour);
            return arr;
        }
        static bool MuffinMix(double water, double flour)
        {
            double[] percents = GetPercent(water, flour);
            bool flag = false;
            if (percents[0] == 40 && percents[1] == 60)
            {
                flag = true;
            }
            return flag;
        }
        static bool BaguetteMix(double water, double flour)
        {
            double[] percents = GetPercent(water, flour);
            bool flag = false;
            if (percents[0] == 30 && percents[1] == 70)
            {
                flag = true;
            }
            return flag;
        }
        static bool BagelMix(double water, double flour)
        {
            double[] percents = GetPercent(water, flour);
            bool flag = false;
            if (percents[0] == 20 && percents[1] == 80)
            {
                flag = true;
            }
            return flag;
        }
        static bool CroissantMix(double water, double flour)
        {
            double[] percents = GetPercent(water, flour);
            bool flag = false;
            if (percents[0] == 50 && percents[1] == 50)
            {
                flag = true;
            }
            return flag;
        }
    }
}
