﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace _02._Beaver_at_Work
{
    internal class Program
    {
        private static char[,] matrix;
        private static int r;
        private static int c;
        private static string direction;
        private static int totalBranches = 0;
        private static List<char> collectedBranches;
        static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            matrix = new char[n,n];
           
            collectedBranches = new List<char>();
            for (int i = 0; i < n; i++)
            {
                char[] input = Console.ReadLine()
                    .Replace(" ", "")
                    .ToCharArray();

                for (int j = 0; j < input.Length; j++)
                {
                    matrix[i, j] = input[j];

                    if (matrix[i, j] == 'B')
                    {
                        r = i;
                        c = j;
                    }
                    else if (char.IsLower(matrix[i, j]))
                    {
                        totalBranches++;
                    }
                }
            }
            string cmd = Console.ReadLine();
            while (cmd != "end")
            {
                direction = cmd;
                if (cmd == "up")
                {
                    Move(-1, 0);
                    //error checking
                    //for (int i = 0; i < n; i++)
                    //{
                    //    for (int j = 0; j < n; j++)
                    //    {
                    //        Console.Write($"{matrix[i, j]} ");
                    //    }
                    //    Console.WriteLine();
                    //}
                }
                else if (cmd == "down")
                {
                    Move(1, 0);
                    //error checking
                    //for (int i = 0; i < n; i++)
                    //{
                    //    for (int j = 0; j < n; j++)
                    //    {
                    //        Console.Write($"{matrix[i, j]} ");
                    //    }
                    //    Console.WriteLine();
                    //}
                }
                else if (cmd == "right")
                {
                    Move(0, 1);
                    //error checking
                    //for (int i = 0; i < n; i++)
                    //{
                    //    for (int j = 0; j < n; j++)
                    //    {
                    //        Console.Write($"{matrix[i, j]} ");
                    //    }
                    //    Console.WriteLine();
                    //}
                }
                else if (cmd == "left")
                {
                    Move(0, -1);
                    //error checking
                    //for (int i = 0; i < n; i++)
                    //{
                    //    for (int j = 0; j < n; j++)
                    //    {
                    //        Console.Write($"{matrix[i, j]} ");
                    //    }
                    //    Console.WriteLine();
                    //}
                }
                if ( totalBranches  == 0)
                {
                    break;
                }
                cmd = Console.ReadLine();
            }
            
            if (totalBranches > 0)
            {
                Console.WriteLine($"The Beaver failed to collect every wood branch. There are {totalBranches} branches left.");
                
            }
            else
            {
                Console.WriteLine($"The Beaver successfully collect {collectedBranches.Count} wood branches: {string.Join(", ", collectedBranches)}.");
            }
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    Console.Write((char)matrix[i, j]);
                    Console.Write(' ');
                }
                Console.WriteLine();
            }
        }
        static void Move(int nextR,int nextC)
        {
            if (!IsInside(r + nextR, c + nextC))
            {
                if (collectedBranches.Any())
                {
                    collectedBranches.Remove(collectedBranches[collectedBranches.Count - 1]);
                    
                }
                return;
            }
            matrix[r, c] = '-';
            r += nextR;
            c += nextC;
            if (char.IsLower(matrix[r,c]))
            {
                collectedBranches.Add(matrix[r, c]);
                matrix[r, c] = 'B';
                totalBranches--;
            }
            else if (matrix[r,c] == 'F')
            {
                matrix[r, c] = '-';
                if (direction == "up")
                {
                    if (r == 0)
                    {
                        if (char.IsLower(matrix[matrix.GetLength(0) - 1,c]))
                        {
                            collectedBranches.Add(matrix[matrix.GetLength(0) - 1, c]);
                            totalBranches--;
                        }
                        r = matrix.GetLength(0) - 1;
                        matrix[r, c] = 'B';
                    }
                    else
                    {
                        if (char.IsLower(matrix[0, c]))
                        {
                            collectedBranches.Add(matrix[0, c]);
                            totalBranches--;
                        }
                        r = 0;
                        matrix[r, c] = 'B';
                    }
                }
                else if (direction == "down")
                {
                    if (r == matrix.GetLength(0) - 1)
                    {
                        if (char.IsLower(matrix[0, c]))
                        {
                            collectedBranches.Add(matrix[0, c]);
                            totalBranches--;
                        }
                        r = 0;
                        matrix[r, c] = 'B';
                    }
                    else
                    {
                        if (char.IsLower(matrix[matrix.GetLength(0)-1,c]))
                        {
                            collectedBranches.Add(matrix[matrix.GetLength(0)-1, c]);
                            totalBranches--;
                        }
                        r = matrix.GetLength(0) - 1;
                        matrix[r, c] = 'B';
                    }
                }
                else if (direction == "left")
                {
                    if (c == 0)
                    {
                        if (char.IsLower(matrix[r, matrix.GetLength(1)-1]))
                        {
                            collectedBranches.Add(matrix[r, matrix.GetLength(1)-1]);
                            totalBranches--;
                        }
                        c = matrix.GetLength(1)-1;
                        matrix[r, c] = 'B';
                    }
                    else
                    {
                        if (char.IsLower(matrix[r, 0]))
                        {
                            collectedBranches.Add(matrix[r, 0]);
                            totalBranches--;
                        }
                        c = 0;
                        matrix[r, c] = 'B';
                    }
                }
                else if (direction == "right")
                {
                    if (c == matrix.GetLength(1)-1)
                    {
                        if (char.IsLower(matrix[r, 0]))
                        {
                            collectedBranches.Add(matrix[r, 0]);
                            totalBranches--;
                        }
                        c = 0;
                        matrix[r, c] = 'B';
                    }
                    else
                    {
                        if (char.IsLower(matrix[r, matrix.GetLength(1) - 1]))
                        {
                            collectedBranches.Add(matrix[r, matrix.GetLength(1) - 1]);
                            totalBranches--;
                        }
                        c = matrix.GetLength(1) - 1;
                        matrix[r, c] = 'B';
                    }
                }
                else
                {
                    matrix[r, c] = 'B';
                }
            }

        }
        static bool IsInside(int r, int c)
        {
             return r >= 0 && r < matrix.GetLength(0) &&
                   c >= 0 && c < matrix.GetLength(1);
        }
    }
}
