﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace _4._Matrix_Shuffling
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] dim = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();
            string[,] matrix = new string[dim[0], dim[1]];
            int counter = 0;
            for (int i = 0; i < dim[0]; i++)
            {
                string[] numbers = Console.ReadLine().Split(" ");
                for (int j = 0; j < dim[1]; j++)
                {
                    matrix[i, j] = numbers[j];
                }
            }
            while (true)
            {
                string[] cmd = Console.ReadLine().Split(" ");
                if (cmd[0] == "END" && cmd.Length == 1)
                {
                    break;
                }
                else if (cmd[0] == "swap" && cmd.Length == 5)
                {
                    int r1 = int.Parse(cmd[1]);
                    int c1 = int.Parse(cmd[2]);
                    int r2 = int.Parse(cmd[3]);
                    int c2 = int.Parse(cmd[4]);
                    if (r1 >= 0 && r1 < matrix.GetLength(0)
                        && c1 >= 0 && c1 < matrix.GetLength(1)
                        && r2 >= 0 && r2 < matrix.GetLength(0)
                        && c2 >= 0 && c2 < matrix.GetLength(1)
                        )
                    {
                        string toswap = matrix[r1, c1];
                        matrix[r1, c1] = matrix[r2, c2];
                        matrix[r2, c2] = toswap;
                        for (int r = 0; r < matrix.GetLength(0); r++)
                        {
                            for (int c = 0; c < matrix.GetLength(1); c++)
                            {
                                Console.Write(matrix[r, c] + " ");
                            }
                            Console.WriteLine();
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid input!");
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input!");
                }
            }
        }
    }
}
