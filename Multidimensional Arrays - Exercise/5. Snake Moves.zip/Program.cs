﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace _5._Snake_Moves
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] dim = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
            char[,] matrix = new char[dim[0], dim[1]];
            var queue = new Queue<char>();
            int counter  = 0;
            int capacity = dim[0]*dim[1];
            string snake = Console.ReadLine();
            for (int i = 0; i < snake.Length; i++)
            {
                queue.Enqueue(snake[i]);
                counter++;
                if (i == snake.Length -1)
                {
                    i = -1;
                }
                if (counter == capacity)
                {
                    break;
                }
            }
            for (int r = 0; r < dim[0]; r++)
            {
                if (r % 2 == 0)
                {
                    for (int c = 0; c < dim[1]; c++)
                    {

                        matrix[r, c] = queue.Dequeue();
                    }
                }
                else if (r % 2 != 0)
                {
                    for (int j = dim[1] - 1; j > -1; j--)
                    {
                        matrix[r, j] = queue.Dequeue();
                    }
                } 
            }
            for (int row = 0; row < matrix.GetLength(0); row++)
            {
                for (int col = 0; col < matrix.GetLength(1); col++)
                {
                    Console.Write("{0}", matrix[row, col]);
                }

                Console.WriteLine();
            }
        }
    }
}
