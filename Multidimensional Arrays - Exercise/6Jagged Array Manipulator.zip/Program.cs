﻿using System;
using System.Linq;

namespace _6Jagged_Array_Manipulator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            double[][] jagged = new double[n][];
            for (int i = 0; i < n; i++)
            {
                jagged[i] = Console.ReadLine().Split(' ').Select(double.Parse).ToArray();
            }
            for (int i = 0; i < n - 1; i++)
            {
                if (jagged[i].Length == jagged[i + 1].Length)
                {
                    for (int j = 0; j < jagged[i].Length; j++)
                    {
                        jagged[i][j] *= 2;
                        jagged[i + 1][j] *= 2;
                    }
                }
                else
                {
                    for (int j = 0; j < jagged[i].Length; j++)
                    {
                        jagged[i][j] /= 2;
                    }
                    for (int k = 0; k < jagged[i + 1].Length; k++)
                    {
                        jagged[i + 1][k] /= 2;
                    }
                }
            }
            while (true)
            {
                string[] cmd = Console.ReadLine().Split(' ');
                if (cmd[0] == "End")
                {
                    break;
                }
                else if (cmd[0] == "Add")
                {
                    int row = int.Parse(cmd[1]);
                    int coll = int.Parse(cmd[2]);
                    int value = int.Parse(cmd[3]);
                    if (row >= 0 && row < jagged.Length
                        && coll >= 0 && coll < jagged[row].Length)
                    {
                        jagged[row][coll] += value;
                    }
                }
                else if (cmd[0] == "Subtract")
                {
                    int row = int.Parse(cmd[1]);
                    int coll = int.Parse(cmd[2]);
                    int value = int.Parse(cmd[3]);
                    if (row >= 0 && row < jagged.Length
                        && coll >= 0 && coll < jagged[row].Length)
                    {
                        jagged[row][coll] -= value;
                    }
                }
            }
            
            foreach (var item in jagged)
            {
                Console.WriteLine(String.Join(" ",item));
            }
        }
    }
}
