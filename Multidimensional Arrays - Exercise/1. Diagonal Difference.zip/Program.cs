﻿using System;
using System.Linq;

namespace _1._Diagonal_Difference
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int dim = int.Parse(Console.ReadLine());
            int[,] matrix = new int[dim,dim];
            int mainDiagonal = 0;
            int reverseDiagonal = 0;
            for (int i = 0; i < dim; i++)
            {
                int[] nimbers = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
                for (int j = 0; j < dim; j++)
                {
                    matrix[i,j] = nimbers[j];
                }
            }
            for (int r = 0; r < matrix.GetLength(0); r++)
            {
                for (int c = 0; c < matrix.GetLength(1); c++)
                {
                    if (r==c)
                    {
                        mainDiagonal += matrix[r, c];
                    }
                }
            }
            for (int row = 0, col = dim - 1; row < dim; row++, col--)
            {
                reverseDiagonal += matrix[row,col];
            }
            int difference = Math.Abs(mainDiagonal - reverseDiagonal);
            Console.WriteLine(difference);
            
        }
    }
}
