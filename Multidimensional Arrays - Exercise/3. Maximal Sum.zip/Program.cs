﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Numerics;

namespace _3._Maximal_Sum
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] dim = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();
            int[,] matrix = new int[dim[0], dim[1]];
            int max = int.MinValue;
            string firstLine = "";
            string secondLine = "";
            string thirdLine = "";
            for (int i = 0; i < dim[0]; i++)
            {
                int[] numbers = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();
                for (int j = 0; j < dim[1]; j++)
                {
                    matrix[i, j] = numbers[j];
                }
            }
            for (int r = 0; r < matrix.GetLength(0) - 2; r++)
            {
                for (int c = 0; c < matrix.GetLength(1) - 2; c++)
                {
                    int sum = matrix[r, c] + matrix[r, c+1] + matrix[r, c+2] 
                        +matrix[r+1, c] + matrix[r+1, c+1] + matrix[r+1, c+2]+
                        matrix[r+2, c] +matrix[r+2, c+1] + matrix[r+2, c+2];
                    if (max< sum)
                    {
                        max = sum;
                        firstLine = ($"{matrix[r, c]} {matrix[r, c + 1]} {matrix[r, c + 2]}");
                        secondLine = ($"{matrix[r + 1, c]} {matrix[r + 1, c + 1]} {matrix[r + 1, c + 2]}");
                        thirdLine = ($"{matrix[r + 2, c]} {matrix[r + 2, c + 1]} {matrix[r + 2, c + 2]}");
                    }
                }
            }
            Console.WriteLine($"Sum = {max}");
            Console.WriteLine(firstLine);
            Console.WriteLine(secondLine);
            Console.WriteLine(thirdLine);
        }
    }
}
