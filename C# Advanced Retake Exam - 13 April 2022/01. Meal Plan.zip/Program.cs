﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace _01._Meal_Plan
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Queue<string> meals = new Queue<string>(Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries));
            int CountofMeals = meals.Count;
            Stack<int> calories = new Stack<int>(Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries).Select(int.Parse));
            while (meals.Any() && calories.Any())
            {
                int currCalories = calories.Peek();
                while (currCalories != 0 && meals.Any())
                {
                    int mealCallories = 0;
                    string mealName = meals.Peek();
                    if (mealName == "salad")
                    {
                        mealCallories = 350;
                        if (currCalories - mealCallories > 0)
                        {
                            currCalories -= mealCallories;
                            meals.Dequeue();
                        }
                        else if (currCalories - mealCallories == 0)
                        {
                            meals.Dequeue();
                            calories.Pop();
                        }
                        else if (currCalories - mealCallories < 0)
                        {
                            meals.Dequeue();
                            calories.Pop();
                            if (calories.Count > 0)
                            {
                                int nextCall = calories.Pop();
                                calories.Push(nextCall + (currCalories - mealCallories));
                                break;
                            }
                            else
                            {
                                break;
                            }
                        }
                    }
                    else if (mealName == "soup")
                    {
                        mealCallories = 490;
                        if (currCalories - mealCallories > 0)
                        {
                            currCalories -= mealCallories;
                            meals.Dequeue();
                        }
                        else if (currCalories - mealCallories == 0)
                        {
                            meals.Dequeue();
                            calories.Pop();
                        }
                        else if (currCalories - mealCallories < 0)
                        {
                            meals.Dequeue();
                            calories.Pop();
                            if (calories.Count > 0)
                            {
                                int nextCall = calories.Pop();
                                calories.Push(nextCall + (currCalories - mealCallories));
                                break;
                            }
                            else
                            {
                                break;
                            }
                        }
                    }
                    else if (mealName == "pasta")
                    {
                        mealCallories = 680;
                        if (currCalories - mealCallories > 0)
                        {
                            currCalories -= mealCallories;
                            meals.Dequeue();
                        }
                        else if (currCalories - mealCallories == 0)
                        {
                            meals.Dequeue();
                            calories.Pop();
                        }
                        else if (currCalories - mealCallories < 0)
                        {
                            meals.Dequeue();
                            calories.Pop();
                            if (calories.Count > 0)
                            {
                                int nextCall = calories.Pop();
                                calories.Push(nextCall + (currCalories - mealCallories));
                                break;
                            }
                            else
                            {
                                break;
                            }
                        }
                    }
                    else if (mealName == "steak")
                    {
                        mealCallories = 790;
                        if (currCalories - mealCallories > 0)
                        {
                            currCalories -= mealCallories;
                            meals.Dequeue();
                        }
                        else if (currCalories - mealCallories == 0)
                        {
                            meals.Dequeue();
                            calories.Pop();
                        }
                        else if (currCalories - mealCallories < 0)
                        {
                            meals.Dequeue();
                            calories.Pop();
                            if (calories.Count > 0)
                            {
                                int nextCall = calories.Pop();
                                calories.Push(nextCall + (currCalories - mealCallories));
                                break;
                            }
                            else
                            {
                                break;
                            }
                        }
                    }
                }
            }
            if (meals.Count == 0)
            {
                Console.WriteLine($"John had {CountofMeals} meals.");
                Console.WriteLine($"For the next few days, he can eat {String.Join(", ",calories)} calories.");
            }
            else
            {
                Console.WriteLine($"John ate enough, he had {CountofMeals - meals.Count} meals.");
                Console.WriteLine($"Meals left: {String.Join(", ",meals)}.");
            }
        }
    }
}
