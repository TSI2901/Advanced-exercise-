﻿using System.Collections.Generic;
using System.Linq;

namespace Zoo
{
    public class Zoo
    {
        public List<Animal> Animals { get; set; }
        public string Name { get; set; }
        public int Capacity { get; set; }
        public Zoo(string name,int capacity)
        {
            Name = name;
            Capacity = capacity;
            Animals = new List<Animal>();
        }
        public string AddAnimal(Animal animal)
        {
            
            if (Animals.Count < Capacity)
            {
                if (string.IsNullOrEmpty(animal.Species))
                {
                    return "Invalid animal species.";
                }
                else
                {
                    if (animal.Diet != "herbivore" && animal.Diet != "carnivore")
                    {
                        return "Invalid animal diet.";
                    }
                    else
                    {
                        Animals.Add(animal);
                        return $"Successfully added {animal.Species} to the zoo.";
                    }
                }
            }
            else
            {
                return "The zoo is full.";
            }
            return "";
        }
        public int RemoveAnimals(string species)
        {
            int count = 0;
            List<Animal> animalsToRemove = new List<Animal>();
            if (Animals.Count > 0)
            {
                foreach (var item in Animals)
                {
                    if (item.Species == species)
                    {
                        animalsToRemove.Add(item);
                        count++;
                    }
                }
                foreach (var item in animalsToRemove)
                {
                    Animals.Remove(item);
                }
            }
            return count;
        }
        public List<Animal> GetAnimalsByDiet(string diet)
        {
            List<Animal> SearchedAnimals = new List<Animal>();
            if (Animals.Count > 0)
            {
                foreach (var item in Animals)
                {
                    if (item.Diet == diet)
                    {
                        SearchedAnimals.Add(item);
                    }
                }
            }
            return SearchedAnimals;
        }
        public Animal GetAnimalByWeight(double weight)
        {
            Animal SearchedAnimal = null;
            if (Animals.Count > 0)
            {
                foreach (var item in Animals)
                {
                    if (item.Weight == weight)
                    {
                        SearchedAnimal = item;
                        break;
                    }
                }
            }
            return SearchedAnimal;
        }
        public string GetAnimalCountByLength(double minimumLength, double maximumLength)
        {
            int count = 0;
            if (Animals.Count > 0)
            {
                foreach (var item in Animals)
                {
                    if (item.Length >= minimumLength && item.Length <= maximumLength)
                    {
                        count++;
                    }
                }
            }
            return $"There are {count} animals with a length between {minimumLength} and {maximumLength} meters.";
        }
    }
}
