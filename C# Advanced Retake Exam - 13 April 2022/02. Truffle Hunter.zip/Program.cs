﻿using System;
using System.Linq;

namespace _02._Truffle_Hunter
{
    internal class Program
    {
        static private char[,] matrix;
        static private int Alltruffels;
        static private int BoarTruffels;
        static private int Bcounter;
        static private int Wcounter;
        static private int Scounter;
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            matrix = new char[n,n];
            Bcounter = 0;
            Wcounter = 0;
            Scounter = 0;
            for (int i = 0; i < n; i++)
            { 
                char[] input = Console.ReadLine().Split(' ').Select(char.Parse).ToArray();
                for (int j = 0; j < input.Length; j++)
                {
                    matrix[i,j] = input[j];
                    if (char.IsLetter(matrix[i,j]))
                    {
                        Alltruffels++;
                    }
                }
            }
            

            while (true)
            {
                string[] input = Console.ReadLine().Split(' ');
                string cmd = input[0];
                if (cmd == "Stop")
                {
                    break;
                }
                else if (cmd == "Collect")
                {
                    int row = int.Parse(input[1]);
                    int coll = int.Parse(input[2]);
                    if (IsInside(row,coll))
                    {
                        AddTruffel(row, coll);
                    }
                }
                else if (cmd == "Wild_Boar")
                {
                    int row = int.Parse(input[1]);
                    int coll = int.Parse(input[2]);
                    string direction = input[3];
                    AddBoarTruffel(row, coll);

                    if (direction == "up")
                    {
                        while (true)
                        {
                            row -= 2;
                            if (IsInside(row, coll))
                            {
                                AddBoarTruffel(row, coll);
                                
                            }
                            else
                            {
                                break;
                            }
                        }
                    }
                    else if (direction == "down")
                    {
                        while (true)
                        {
                            row += 2;
                            if (IsInside(row, coll))
                            {
                                AddBoarTruffel(row, coll);
                                
                            }
                            else
                            {
                                break;
                            }
                        }
                    }
                    else if (direction == "left")
                    {
                        while (true)
                        {
                            coll -= 2;
                            if (IsInside(row, coll))
                            {
                                AddBoarTruffel(row, coll);
                            }
                            else
                            {
                                break;
                            }
                        }
                    }
                    else if (direction == "right")
                    {
                        while (true)
                        {
                            coll += 2;
                            if (IsInside(row, coll))
                            {
                                AddBoarTruffel(row, coll);
                            }
                            else
                            {
                                break;
                            }
                        }
                    }
                }
                if (Alltruffels == 0)
                {
                    break;
                }
            }
            Console.WriteLine($"Peter manages to harvest {Bcounter} black, {Scounter} summer, and {Wcounter} white truffles.");
            Console.WriteLine($"The wild boar has eaten {BoarTruffels} truffles.");
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    Console.Write(matrix[i,j] + " ");
                }
                Console.WriteLine();
            }
        }
        static bool IsInside(int row,int coll)
        {
            return row >= 0 && coll >= 0 
                && row < matrix.GetLength(0) && coll < matrix.GetLength(1);
        }
        static void AddTruffel(int row,int coll)
        {
            int currB = Bcounter;
            int currW = Wcounter;
            int currS = Scounter;
            if (matrix[row, coll] == 'B')
            {
                Bcounter++;
                matrix[row, coll] = '-';
                Alltruffels--;
            }
            else if (matrix[row, coll] == 'W')
            {
                Wcounter++;
                matrix[row, coll] = '-';
                Alltruffels--;
            }
            else if (matrix[row, coll] == 'S')
            {
                Scounter++;
                matrix[row, coll] = '-';
                Alltruffels--;
            }
        }
        static void AddBoarTruffel(int row, int coll)
        {
            int currB = Bcounter;
            int currW = Wcounter;
            int currS = Scounter;
            if (matrix[row, coll] == 'B')
            {
                BoarTruffels++;
                matrix[row, coll] = '-';
                Alltruffels--;
            }
            else if (matrix[row, coll] == 'W')
            {
                BoarTruffels++;
                matrix[row, coll] = '-';
                Alltruffels--;
            }
            else if (matrix[row, coll] == 'S')
            {
                BoarTruffels++;
                matrix[row, coll] = '-';
                Alltruffels--;
            }
        }
    }
}
