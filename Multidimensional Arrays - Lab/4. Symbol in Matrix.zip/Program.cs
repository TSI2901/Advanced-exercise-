﻿using System;
using System.Linq;

namespace _4._Symbol_in_Matrix
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            char[,] matrix = new char[n, n];
            int neededRow = 0;
            int neededColl = 0;
            bool flag = false;
            for (int i = 0; i < n; i++)
            {
                string input =Console.ReadLine();
                char[] chars =input.ToCharArray();
                for (int j = 0; j < n; j++)
                {
                    matrix[i, j] = chars[j];
                }
            }
            char ch = char.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    int ascii = (int)matrix[i, j];
                    if (ascii == (int)ch)
                    {
                        neededRow=i;
                        neededColl=j;
                        flag=true;
                        break;
                    }
                    if (flag)
                    {
                        break;
                    }
                }
            }
            if (flag)
            {
                Console.WriteLine($"({neededRow}, {neededColl})");
            }
            else
            {
                Console.WriteLine($"{ch} does not occur in the matrix ");
            }
           
        }
    }
}
