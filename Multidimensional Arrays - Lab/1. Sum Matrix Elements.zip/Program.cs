﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace _1._Sum_Matrix_Elements
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] dim = Console.ReadLine().Split(", ").Select(int.Parse).ToArray();
            int[,] matrix = new int[dim[0], dim[1]];
            for (int i = 0; i < dim[0]; i++)
            {
                int[] numbers = Console.ReadLine().Split(", ").Select(int.Parse).ToArray();
                for (int j = 0; j < dim[1]; j++)
                {
                    matrix[i, j] = numbers[j];
                }
            }
            int sum = 0;
            for (int row = 0; row < matrix.GetLength(0); row++)
            {
                for (int col = 0; col < matrix.GetLength(1); col++)
                {
                    sum += matrix[row, col];
                }
            }
            Console.WriteLine(dim[0]);
            Console.WriteLine(dim[1]);
            Console.WriteLine(sum);
        }
    }
}
