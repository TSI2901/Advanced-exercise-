﻿using System;
using System.Linq;

namespace _5._Square_With_Maximum_Sum
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] dim = Console.ReadLine().Split(", ").Select(int.Parse).ToArray();
            int[,] matrix = new int[dim[0], dim[1]];
            int max = int.MinValue;
            int row = 0;
            int col = 0;    
            for (int i = 0; i < dim[0]; i++)
            {
                int[] numbers = Console.ReadLine().Split(", ").Select(int.Parse).ToArray();
                for (int j = 0; j < dim[1]; j++)
                {
                    matrix[i, j] = numbers[j];
                }
            }
            for (int r = 0; r < matrix.GetLength(0)-1; r++)
            {
                int sum = 0;
                for (int c = 0; c < matrix.GetLength(1)-1; c++)
                {
                    sum = matrix[r, c] + matrix[r, c + 1] + matrix[r + 1, c] + matrix[r + 1, c + 1];
                    if (sum > max)
                    {
                        max = sum;
                        row = r;
                        col = c;
                    }
                }
            }
            Console.WriteLine($"{matrix[row,col]} {matrix[row,col+1]}");
            Console.WriteLine($"{matrix[row+1,col]} {matrix[row+1,col+1]}");
            Console.WriteLine(max);
        }
    }
}
