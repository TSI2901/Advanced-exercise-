﻿using System;
using System.Linq;

namespace _3._Primary_Diagonal
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int dim = int.Parse(Console.ReadLine());
            int[,] matrix = new int[dim, dim];
            for (int i = 0; i < dim; i++)
            {
                int[] numbers = Console.ReadLine().Split(" ").Select(int.Parse).ToArray();
                for (int j = 0; j < dim; j++)
                {
                    matrix[i, j] = numbers[j];
                }
            }
            int sum = 0;
            for (int r = 0; r < matrix.GetLength(0); r++)
            {
                for (int c = 0; c < matrix.GetLength(1); c++)
                {
                    if (r == c)
                    {
                        sum += matrix[r, c];
                    }
                }
            }
            Console.WriteLine(sum);
        }
    }
}
