﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
    public class Car
    {
        private string name;
        private double fuelAmount;
        private double fuelPerKilo;
        private double travelled;

        
        public Car(string model,double fuel,double fuelPerKilo)
        {
            Name = model;
            FuelAmount = fuel;
            FuelPerKilo = fuelPerKilo;
            Travelled = 0;
        }
        public string Name { get; set; }
        public double FuelAmount { get; set; }
        public double FuelPerKilo { get; set; }
        public double Travelled { get; set; }

        public void Drive(double km)
        {
            double neededLites = km  * FuelPerKilo;
            if (neededLites <= FuelAmount)
            {
                FuelAmount -= neededLites;
                Travelled += km;
            }
            else
            {
                Console.WriteLine("Insufficient fuel for the drive");
            }
        }
    }
}
