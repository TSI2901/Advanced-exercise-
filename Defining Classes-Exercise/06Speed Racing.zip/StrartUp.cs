﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DefiningClasses
{
    internal class StrartUp
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            List<Car> cars = new List<Car>();
            for (int i = 0; i < n; i++)
            {
                string input = Console.ReadLine();
                string model = input.Split(' ')[0];
                double fuelAmount = double.Parse(input.Split(' ')[1]);
                double fuelConsumption = double.Parse(input.Split(' ')[2]);
                Car car = new Car(model, fuelAmount, fuelConsumption);
                cars.Add(car);
            }
            while (true)
            {
                string input = Console.ReadLine();
                string cmd = input.Split(' ')[0];
                if (cmd == "End")
                {
                    break;
                }
                string model = input.Split(' ')[1];
                double km = double.Parse(input.Split(' ')[2]);
                
                if (cmd == "Drive")
                {
                    Car carTodrive = cars.First(car => car.Name == model);
                    carTodrive.Drive(km);
                }
            }
            foreach (var item in cars)
            {
                Console.WriteLine($"{item.Name} {item.FuelAmount:F2} {item.Travelled}");
            }
        }
    }
}
