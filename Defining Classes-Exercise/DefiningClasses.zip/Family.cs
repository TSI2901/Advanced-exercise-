﻿using DefiningClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Defining_Classes
{
    public class Family
    {
        private List<Person> familymembers;

        public Family()
        {
            this.familymembers = new List<Person>();
        }
        public void AddMember(Person member)
        {
            this.familymembers.Add(member);
        }
        public List<Person> GettheOldest()
        {
            familymembers = familymembers.OrderBy(x => x.Name).ToList();
            familymembers = familymembers.Where(x => x.Age > 30).ToList();
            return familymembers;
        }
    }
}
