﻿using System;
using System.Linq;

namespace _04._Add_VAT
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Func<double, double> addVAT = x => x * 1.2;
            double[] nums = Console.ReadLine().Split(", ").Select(double.Parse).ToArray();
            double[] nums2 = nums.Select(addVAT).ToArray();
            foreach (var item in nums2)
            {
                Console.WriteLine("{0:F2}",item);
            }
        }
    }
}
