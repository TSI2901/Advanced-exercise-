﻿using System;
using System.Linq;

namespace _03._Count_Uppercase_Words
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Predicate<string> predicate = (string x) => x.Length > 0 && char.IsUpper(x[0]);
            string[] arr = Console.ReadLine().Split(' ').Where(x => predicate(x)).ToArray();
            Console.WriteLine(String.Join("\r\n",arr));
        }
    }
}
