﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace _09._Predicate_Party_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<string> list = Console.ReadLine().Split(' ').ToList();
            while (true)
            {
                string[] cmd = Console.ReadLine().Split(' ').ToArray();
                if (cmd[0] == "Party!")
                {
                    break;
                }
                else if (cmd[0] == "Remove")
                {
                    if (cmd[1] == "StartsWith")
                    {
                        for (int i = 0; i < list.Count; i++)
                        {
                            if (list[i].StartsWith(cmd[2]))
                            {
                                list.Remove(list[i]);
                            }
                        }
                    }
                    else if (cmd[1] == "EndsWith")
                    {
                        for (int i = 0; i < list.Count; i++)
                        {
                            if (list[i].EndsWith(cmd[2]))
                            {
                                list.Remove(list[i]);
                            }
                        }
                    }
                    
                }
                else if (cmd[0] == "Double")
                {
                    if (cmd[1] == "Length")
                    {
                        for (int i = 0; i < list.Count; i++)
                        {
                            if (list[i].Length == int.Parse(cmd[2]))
                            {
                                list.Insert(i+1, list[i]);
                                i++;
                            }
                        }
                    }
                    else if (cmd[1] == "StartsWith")
                    {
                        for (int i = 0; i < list.Count; i++)
                        {
                            if (list[i].StartsWith(cmd[2]))
                            {
                                list.Insert(i + 1, list[i]);
                                i++;
                            }
                        }
                    }
                    else if (cmd[1] == "EndsWith")
                    {
                        for (int i = 0; i < list.Count; i++)
                        {
                            if (list[i].EndsWith(cmd[2]))
                            {
                                list.Insert(i + 1, list[i]);
                                i++;
                            }
                        }
                    }
                }
            }
            if (list.Count > 0)
            {
                Console.WriteLine($"{String.Join(", ",list)} are going to the party!");
            }
            else
            {
                Console.WriteLine("Nobody is going to the party!");
            }
        }
    }
}
