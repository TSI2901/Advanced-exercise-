﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _05._Applied_Arithmetics
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<double> list = Console.ReadLine().Split(' ').Select(double.Parse).ToList();
            while (true)
            {
                string cmd = Console.ReadLine();
                if (cmd == "end")
                {
                    break;
                }
                else if (cmd == "add")
                {
                    list = list.Select(x => ++x).ToList();
                }
                else if (cmd == "multiply")
                {
                    list = list.Select(x => 2*x).ToList();
                }
                else if (cmd == "subtract")
                {
                    list = list.Select(x => --x).ToList();
                }
                else if (cmd == "print")
                {
                    Console.WriteLine(String.Join(" ", list));
                }
            }
            
        }
    }
}
