﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace _07._Predicate_For_Names
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string[] arr = Console.ReadLine().Split(' ').ToArray();
            arr = arr.Where(x => x.Length <= n).ToArray();
            Console.WriteLine(String.Join("\r\n",arr));
        }
    }
}
