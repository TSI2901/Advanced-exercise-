﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace _06._Reverse_And_Exclude
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<double> list = Console.ReadLine().Split(' ',StringSplitOptions.RemoveEmptyEntries).Select(double.Parse).Reverse().ToList();
            int n = int.Parse(Console.ReadLine());
            list = list.Where(x => x % n >= 1 ||(x % n <= -1  && x % n != 0)).ToList();
            Console.WriteLine(String.Join(" ",list));
        }
    }
}
