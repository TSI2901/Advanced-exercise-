﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
            List<int> list = new List<int>();
            for (int i = arr[0]; i <= arr[1]; i++)
            {
                list.Add(i);
            }
            string cmd = Console.ReadLine();
            if (cmd == "odd")
            {
                list = list.Where(x => x % 2 == 1 || x % 2 == -1).ToList();
                Console.WriteLine(String.Join(" ", list));
            }
            else if (cmd == "even")
            {
                list = list.Where(x => x % 2 == 0).ToList();
                Console.WriteLine(String.Join(" ", list));
            }

        }
    }
}