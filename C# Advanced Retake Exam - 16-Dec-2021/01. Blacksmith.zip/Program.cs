﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace _01._Blacksmith
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Queue<int> steel = new Queue<int>(Console.ReadLine().Split(' ').Select(int.Parse));
            Stack<int> carbon = new Stack<int>(Console.ReadLine().Split(' ').Select(int.Parse));
            SortedDictionary<string, int> dic = new SortedDictionary<string, int>();
            int totalNumberOfSwords = 0;
            while (steel.Any() && carbon.Any())
            {
                int currSteel = steel.Peek();
                int currCarbon = carbon.Peek();
                int sum = currSteel + currCarbon;
                if (sum == 70)
                {
                    if (dic.ContainsKey("Gladius"))
                    {
                        dic["Gladius"]++;
                    }
                    else
                    {
                        dic.Add("Gladius", 1);
                    }
                    steel.Dequeue();
                    carbon.Pop();
                    totalNumberOfSwords++;
                }
                else if (sum == 80)
                {
                    if (dic.ContainsKey("Shamshir"))
                    {
                        dic["Shamshir"]++;
                    }
                    else
                    {
                        dic.Add("Shamshir", 1);
                    }
                    steel.Dequeue();
                    carbon.Pop();
                    totalNumberOfSwords++;
                }
                else if (sum == 90)
                {
                    if (dic.ContainsKey("Katana"))
                    {
                        dic["Katana"]++;
                    }
                    else
                    {
                        dic.Add("Katana", 1);
                    }
                    steel.Dequeue();
                    carbon.Pop();
                    totalNumberOfSwords++;
                }
                else if (sum == 110)
                {
                    if (dic.ContainsKey("Sabre"))
                    {
                        dic["Sabre"]++;
                    }
                    else
                    {
                        dic.Add("Sabre", 1);
                    }
                    steel.Dequeue();
                    carbon.Pop();
                    totalNumberOfSwords++;
                }
                else if (sum == 150)
                {
                    if (dic.ContainsKey("Broadsword"))
                    {
                        dic["Broadsword"]++;
                    }
                    else
                    {
                        dic.Add("Broadsword", 1);
                    }
                    steel.Dequeue();
                    carbon.Pop();
                    totalNumberOfSwords++;
                }
                else
                {
                    steel.Dequeue();
                    carbon.Pop();
                    carbon.Push(currCarbon + 5);
                }
            }
            if (dic.Count > 0)
            {
                Console.WriteLine($"You have forged {totalNumberOfSwords} swords.");
                if (steel.Count > 0)
                {
                    Console.WriteLine($"Steel left: {String.Join(", ", steel)}");
                }
                else
                {
                    Console.WriteLine("Steel left: none");
                }
                if (carbon.Count > 0)
                {
                    Console.WriteLine($"Carbon left: {String.Join(", ", carbon)}");
                }
                else
                {
                    Console.WriteLine("Carbon left: none");
                }
                foreach (var item in dic)
                {
                    Console.WriteLine($"{item.Key}: {item.Value}");
                }
            }
            else
            {
                Console.WriteLine("You did not have enough resources to forge a sword.");
                if (steel.Count > 0)
                {
                    Console.WriteLine($"Steel left: {String.Join(", ", steel)}");
                }
                else
                {
                    Console.WriteLine("Steel left: none");
                }
                if (carbon.Count > 0)
                {
                    Console.WriteLine($"Carbon left: {String.Join(", ", carbon)}");
                }
                else
                {
                    Console.WriteLine("Carbon left: none");
                }
            }
            
        }
        
    }
}
