﻿using System;
using System.Collections.Generic;

namespace _3._Simple_Calculator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            Stack<int> stack = new Stack<int>();
            for (int i = 0; i < input.Length; i++)
            {
                char c = input[i];
                if (c == '(')
                {
                    stack.Push(i);
                }
                else if (c == ')')
                {
                    int start = stack.Pop();
                    int end = i;
                    string sub = input.Substring(start, end - start+1);
                    Console.WriteLine(sub);
                }
            }
        }
    }
}
