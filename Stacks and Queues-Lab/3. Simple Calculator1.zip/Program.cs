﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _3._Simple_Calculator1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            string[] arr = input.Split(' ');
            int all = 0;
            int sum = 0;
            Stack<string> stack = new Stack<string>();
            Stack<string> revstack = new Stack<string>();
            Stack<int> st = new Stack<int>();
            for (int i = 0; i < arr.Length; i++)
            {
                stack.Push(arr[i]);
            }
            //foreach (var c in stack)
            //{

            //}
            //Console.WriteLine();
            while (stack.Count != 0)
            {
                revstack.Push(stack.Pop());
            }
            //stack.Reverse();
            if (stack.Count % 2 == 0)
            {
                while (revstack.Count >= 0)
                {
                    int num1 = int.Parse(revstack.Pop());
                    char znak = char.Parse(revstack.Pop());
                    int num2 = int.Parse(revstack.Pop());
                    revstack.Pop();
                    if (znak == '+')
                    {
                        sum = num1 + num2;
                        all += sum;
                    }
                    else if (znak == '-')
                    {
                        sum = num1 - num2;
                        all += sum;
                    }
                    st.Push(sum);
                }
            }
            else
            {
                while (revstack.Count >= 0)
                {
                    int num1 = int.Parse(revstack.Pop());
                    char znak = char.Parse(revstack.Pop());
                    int num2 = int.Parse(revstack.Pop());
                    revstack.Pop();
                    if (znak == '+')
                    {
                        sum = num1 + num2;
                        all += sum;
                    }
                    else if (znak == '-')
                    {
                        sum = num1 - num2;
                        all += sum;
                    }
                    st.Push(sum);
                }
                int outa = int.Parse(revstack.Pop());
                st.Push(outa);
            }
            Console.WriteLine(st.Sum());


        }
    }
}
