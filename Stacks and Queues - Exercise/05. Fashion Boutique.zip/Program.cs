﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace _05._Fashion_Boutique
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] clothes = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
            int capacity = int.Parse(Console.ReadLine());
            int racscounter = 0;
            int sum = 0;
            Stack<int> stack = new Stack<int>(clothes);
            while (stack.Count != 0)
            {
                if (sum + stack.Peek() <= capacity)
                {
                    sum += stack.Peek();
                    stack.Pop();
                }
                else
                {
                    racscounter++;
                    sum = 0;
                }
            }
            Console.WriteLine(racscounter + 1);
        }
    }
}
