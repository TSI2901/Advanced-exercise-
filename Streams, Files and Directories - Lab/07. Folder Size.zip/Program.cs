﻿namespace FolderSize
{
    using System;
    using System.IO;
    public class FolderSize
    {
        static void Main(string[] args)
        {
            string folderPath = @"..\..\..\Files\TestFolder";
            string outputPath = @"..\..\..\Files\output.txt";

            GetFolderSize(folderPath, outputPath);
        }

        public static void GetFolderSize(string folderPath, string outputFilePath)
        {
            decimal sum = 0;
            var dieInfo = new DirectoryInfo(folderPath);
            foreach (var fi in dieInfo.EnumerateFiles("*.*", SearchOption.AllDirectories))
            {
                sum += fi.Length;
            }
            var writer = new StreamWriter(outputFilePath);
            using (writer)
            {
                writer.Write(sum);
            }
            Console.WriteLine(sum);
        }
    }
}
