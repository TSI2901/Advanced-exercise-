﻿namespace MergeFiles
{
    using System;
    using System.IO;
    public class MergeFiles
    {
        static void Main(string[] args)
        {
            var firstInputFilePath = @"..\..\..\Files\input1.txt";
            var secondInputFilePath = @"..\..\..\Files\input2.txt";
            var outputFilePath = @"..\..\..\Files\output.txt";

            MergeTextFiles(firstInputFilePath, secondInputFilePath, outputFilePath);
        }

        public static void MergeTextFiles(string firstInputFilePath, string secondInputFilePath, string outputFilePath)
        {
            string[] input1Lines = File.ReadAllLines(firstInputFilePath);
            string[] input2Lines = File.ReadAllLines(secondInputFilePath);
            var writer = new StreamWriter(outputFilePath);
            if (input1Lines.Length >= input2Lines.Length)
            {
                
                for (int i = 0; i < input1Lines.Length; i++)
                {
                    if (i <= input2Lines.Length - 1)
                    {
                        using (writer)
                        {
                            writer.WriteLine(input1Lines[i]);
                            writer.WriteLine(input2Lines[i]);
                        }
                    }
                    else
                    {
                        using (writer)
                        {
                            writer.WriteLine(input1Lines[i]);
                        }
                    }
                    
                }
                
            }
            else
            {
                using (writer)
                {
                    for (int i = 0; i < input2Lines.Length; i++)
                    {
                        if (i <= input1Lines.Length - 1)
                        {
                            writer.WriteLine(input1Lines[i]);
                            writer.WriteLine(input2Lines[i]);
                        }
                        else
                        {
                            
                            
                            writer.WriteLine(input2Lines[i]);
                            
                        }

                    }
                    
                }
                

            }
        }
    }
}
