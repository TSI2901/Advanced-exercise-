﻿namespace LineNumbers
{
    using System.IO;
    public class LineNumbers
    {
        static void Main(string[] args)
        {
            string inputPath = @"..\..\..\Files\input.txt";
            string outputPath = @"..\..\..\Files\output.txt";

            RewriteFileWithLineNumbers(inputPath, outputPath);
        }

        public static void RewriteFileWithLineNumbers(string inputFilePath, string outputFilePath)
        {
            var reader = new StreamReader(inputFilePath);
            var output = new StreamWriter(outputFilePath);
            using (reader)
            {
                using (output)
                {
                    int linecount = 1;
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        output.WriteLine($"{linecount}. {line}");
                        linecount++;
                    }
                }
                    
            }
        }
    }
}
