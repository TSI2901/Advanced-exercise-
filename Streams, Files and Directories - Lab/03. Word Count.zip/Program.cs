﻿namespace WordCount
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    public class WordCount
    {
        static void Main(string[] args)
        {
            string wordPath = @"..\..\..\Files\words.txt";
            string textPath = @"..\..\..\Files\text.txt";
            string outputPath = @"..\..\..\Files\output.txt";

            CalculateWordCounts(wordPath, textPath, outputPath);
        }

        public static void CalculateWordCounts(string wordsFilePath, string textFilePath, string outputFilePath)
        {
            var wordreder = new StreamReader(wordsFilePath);
            List<string> list = new List<string>();
            using (wordreder)
            {
                string word;
                while ((word = wordreder.ReadLine()) != null) 
                {
                    string[] words = word.Split(' ');
                    foreach (string word2 in words)
                    {
                        list.Add(word2);
                    }
                }
            }

        }
    }
}
