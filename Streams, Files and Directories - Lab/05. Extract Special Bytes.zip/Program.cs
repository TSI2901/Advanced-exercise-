﻿namespace ExtractBytes
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Text;
    public class ExtractBytes
    {
        static void Main(string[] args)
        {
            string binaryFilePath = @"..\..\..\Files\example.png";
            string bytesFilePath = @"..\..\..\Files\bytes.txt";
            string outputPath = @"..\..\..\Files\output.bin";

            ExtractBytesFromBinaryFile(binaryFilePath, bytesFilePath, outputPath);
        }

        public static void ExtractBytesFromBinaryFile(string binaryFilePath, string bytesFilePath, string outputPath)
        {
            var reader = new StreamReader(bytesFilePath);
            byte[] buffer = File.ReadAllBytes(binaryFilePath);
            List<string> list = new List<string>();
            var sb = new StringBuilder();
            while (!reader.EndOfStream)
            {
                list.Add(reader.ReadLine());
            }
            foreach (var item in buffer)
            {
                if (list.Contains(item.ToString()))
                {
                    sb.Append(item.ToString());
                }
            }
            var writer = new StreamWriter(outputPath);
            using (writer)
            {
                writer.WriteLine(sb.ToString());
            }
        }
    }
}
