﻿using System.Collections.Generic;
using System;
using System.Linq;
using System.Text;

namespace StockMarket
{
    public class Investor
    {
        public List<Stock> Portfolio { get; set; }
        public string FullName { get; set; }
        public string EmailAddress { get; set; }
        public decimal MoneyToInvest { get; set; }
        public string BrokerName { get; set; }
        public Investor(string fullName, string emailAdress, decimal moneyToInvest, string brokerName)
        {
            this.Portfolio = new List<Stock>();
            this.FullName = fullName;
            this.EmailAddress = emailAdress;
            this.MoneyToInvest = moneyToInvest;
            this.BrokerName = brokerName;
        }
        public int Count()
        {
           return this.Portfolio.Count;
        }
        public void BuyStock(Stock stock)
        {
            if (stock.MarketCapitalization > 10000 && this.MoneyToInvest >= stock.PricePerShare)
            {
                this.Portfolio.Add(stock);
                MoneyToInvest -= stock.PricePerShare;
            }
        }
        public string SellStock(string companyName, decimal sellPrice)
        {
            bool isexist = false;
            Stock stock = null;
            foreach (Stock item in this.Portfolio)
            {
                if (item.CompanyName == companyName)
                {
                    isexist = true;
                    stock = item;
                }
            }
            if (isexist)
            {
                if (stock.PricePerShare <= sellPrice)
                {
                    this.Portfolio.Remove(stock);
                    this.MoneyToInvest += sellPrice;
                    return $"{companyName} was sold.";
                }
                else
                {
                    return $"Cannot sell {companyName}.";
                }
            }
            else
            {
                return $"{companyName} does not exist.";
            }
        }
        public Stock FindStock(string companyName)
        {
            Stock stock = null;
            foreach (Stock item in this.Portfolio)
            {
                if (item.CompanyName == companyName)
                {
                    stock = item;
                }
            }
            return stock;
        }
        public Stock FindBiggestCompany()
        {
            if (this.Portfolio.Count == 0)
                return null;
            else
            {
                var findStock = this.Portfolio.Max(x => x.MarketCapitalization);
                Stock theBiggestCompany = this.Portfolio.FirstOrDefault(x => x.MarketCapitalization == findStock);
                return theBiggestCompany;
            }
        }
        public string InvestorInformation()
        {
            return $"The investor {this.FullName} with a broker {this.BrokerName} has stocks:" + Environment.NewLine +
            $"{String.Join(Environment.NewLine, this.Portfolio)}";
        }
    }
}
