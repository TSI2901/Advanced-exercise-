﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace _01._Food_Finder
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Queue<char> vowels = new Queue<char>(Console.ReadLine().Split(' ').Select(char.Parse));
            Stack<char> constants = new Stack<char>(Console.ReadLine().Split(' ').Select(char.Parse));
            List<string> words = new List<string>() { "pear", "flour", "pork","olive"};
            List<string> wordsFound = new List<string>();
            while (constants.Any())
            {
                char currvowel = vowels.Dequeue();
                char currconstant = constants.Pop();
                for (int i = 0; i < words.Count; i++)
                {
                    if (words[i].Contains(currvowel))
                    {
                        words[i] = words[i].Replace(currvowel.ToString(), "");
                    }
                    if (words[i].Contains(currconstant))
                    {
                        words[i] = words[i].Replace(currconstant.ToString(), "");
                    }
                }
                vowels.Enqueue(currvowel);
            }
            for (int i = 0; i < words.Count; i++)
            {
                if (words[i].Length == 0)
                {
                    if (i == 0)
                    {
                        wordsFound.Add("pear");
                    }
                    if (i == 1)
                    {
                        wordsFound.Add("flour");
                    }
                    if (i == 2)
                    {
                        wordsFound.Add("pork");
                    }
                    if (i == 3)
                    {
                        wordsFound.Add("olive");
                    }

                }
            }
            Console.WriteLine($"Words found: {wordsFound.Count}");
            if (wordsFound.Count > 0)
            {
                foreach (string word in wordsFound)
                {
                    Console.WriteLine(word);
                }
            }
        }
    }
}
