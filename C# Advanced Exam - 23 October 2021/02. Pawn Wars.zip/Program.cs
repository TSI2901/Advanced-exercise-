﻿using System;
using System.Text;

namespace pawnWars
{
    class Program
    {
        static void Main(string[] args)
        {
            int Wrow = 0;
            int Wcol = 0;

            int Brow = 0;
            int Bcol = 0;

            char[,] matrix = new char[8, 8];
            for (int i = 0; i < 8; i++)
            {
                string input = Console.ReadLine();
                for (int j = 0; j < 8; j++)
                {
                    matrix[i, j] += input[j];

                    if (input[j] == 'w')
                    {
                        Wrow = i;
                        Wcol = j;
                    }
                    if (input[j] == 'b')
                    {
                        Brow = i;
                        Bcol = j;
                    }
                }
            }

            while (true)
            {
                if (IsInMatrix(Wrow - 1, Wcol - 1) && matrix[Wrow - 1, Wcol - 1] == 'b')
                {
                    string position = SetPosition(Wrow - 1, Wcol - 1);
                    Console.WriteLine($"Game over! White capture on {position}.");
                    break;

                }
                else if (IsInMatrix(Wrow - 1, Wcol + 1) && matrix[Wrow - 1, Wcol + 1] == 'b')
                {
                    string position = SetPosition(Wrow - 1, Wcol + 1);
                    Console.WriteLine($"Game over! White capture on {position}.");
                    break;
                }
                else
                {
                    matrix[Wrow, Wcol] = '-';
                    Wrow -= 1;
                    matrix[Wrow, Wcol] = 'w';
                    if (Wrow == 0)
                    {
                        string position = SetPosition(Wrow, Wcol);
                        Console.WriteLine($"Game over! White pawn is promoted to a queen at {position}.");
                        break;
                    }
                }

                if (IsInMatrix(Brow + 1, Bcol - 1) && matrix[Brow + 1, Bcol - 1] == 'w')
                {
                    string position = SetPosition(Brow + 1, Bcol - 1);
                    Console.WriteLine($"Game over! Black capture on {position}.");
                    break;
                }
                else if (IsInMatrix(Brow + 1, Bcol + 1) && matrix[Brow + 1, Bcol + 1] == 'w')
                {
                    string position = SetPosition(Brow + 1, Bcol + 1);
                    Console.WriteLine($"Game over! Black capture on {position}.");
                    break;
                }
                else
                {
                    matrix[Brow, Bcol] = '-';
                    Brow += 1;
                    matrix[Brow, Bcol] = 'b';
                    if (Brow == 7)
                    {
                        string position = SetPosition(Brow, Bcol);
                        Console.WriteLine($"Game over! Black pawn is promoted to a queen at {position}.");
                        break;
                    }
                }
            }

        }

        private static bool IsInMatrix(int row, int col)
        {
            return row >= 0 && row <= 7 && col >= 0 && col <= 7;
        }

        private static string SetPosition(int row, int col)
        {

            var sb = new StringBuilder();

            for (int i = 8; i >= 0; i--)
            {
                if (col == i)
                {
                    sb.Append((char)(i + 97));
                }
            }

            int counter = 8;
            for (int i = 0; i < 8; i++)
            {
                if (row == i)
                {
                    sb.Append(counter);
                }
                counter--;
            }
            return $"{sb}";
        }
    }
}