﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace _06._Wardrobe
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var wardrobe = new Dictionary<string, Dictionary<string,int>>();
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                var command = Console.ReadLine().Split(" -> ").ToList();
                string color = command[0];
                var clothes = command[1].Split(",").ToList();
                if (!wardrobe.ContainsKey(color))
                {
                    wardrobe.Add(color, new Dictionary<string, int>());
                    wardrobe[color] = new Dictionary<string, int>();
                    for (int j = 0; j < clothes.Count; j++)
                    {
                        if (wardrobe[color].ContainsKey(clothes[j]))
                        {
                            wardrobe[color][clothes[j]]++;
                        }
                        else
                        {
                            wardrobe[color].Add(clothes[j], 1);
                        }
                    }
                }
                else
                {
                    for (int j = 0; j < clothes.Count; j++)
                    {
                        if (wardrobe[color].ContainsKey(clothes[j]))
                        {
                            wardrobe[color][clothes[j]]++;
                        }
                        else
                        {
                            wardrobe[color].Add(clothes[j], 1);
                        }
                    }
                } 
            }
            var find = Console.ReadLine().Split(' ').ToList();
            var colorToFind = find[0];
            var clothesToFind = find[1];
            foreach (var color in wardrobe)
            {
                Console.WriteLine($"{color.Key} clothes:");
                foreach (var clothes in color.Value)
                {
                    if (color.Key == colorToFind && clothes.Key == clothesToFind)
                    {
                        Console.WriteLine($"* {clothes.Key} - {clothes.Value} (found!)");
                    }
                    else
                    {
                        Console.WriteLine($"* {clothes.Key} - {clothes.Value}");
                    }
                }
            }
        }
    }
}
