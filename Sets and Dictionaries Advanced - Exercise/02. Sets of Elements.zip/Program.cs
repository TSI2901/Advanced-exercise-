﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace _02._Sets_of_Elements
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var lenghts = Console.ReadLine().Split(' ').Select(int.Parse).ToList();
            var first = new HashSet<double>(lenghts[0]);
            var second = new HashSet<double>(lenghts[1]);
            for (int i = 0; i < lenghts[0]; i++)
            {
                double n = double.Parse(Console.ReadLine());
                first.Add(n);
            }
            for (int i = 0; i < lenghts[1]; i++)
            {
                double a = double.Parse(Console.ReadLine());
                second.Add(a);
            }
            first.IntersectWith(second);
            foreach (var item in first)
            {
                Console.Write(item + " ");
            }
        }
    }
}
