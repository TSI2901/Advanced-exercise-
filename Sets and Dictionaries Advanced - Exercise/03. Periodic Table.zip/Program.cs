﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace _03._Periodic_Table
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var set = new SortedSet<string>();
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                var input = Console.ReadLine().Split(' ').ToList();
                for (int j = 0; j < input.Count; j++)
                {
                    set.Add(input[j]);
                }
            }
            Console.WriteLine(String.Join(" ",set));
        }
    }
}
