﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace _01.Masterchef
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Queue<int> ingredient = new Queue<int>(Console.ReadLine().Split(' ').Select(int.Parse).Where(i => i > 0));
            Stack<int> freshness = new Stack<int>(Console.ReadLine().Split(' ').Select(int.Parse));
            var dishes = new SortedDictionary<string, int>();
            while (freshness.Any() && ingredient.Any())
            {
                int curringredient = ingredient.Peek();
                int currfreshness = freshness.Peek();
                int sum = currfreshness * curringredient;
                if (sum == 150)
                {
                    if (dishes.ContainsKey("Dipping sauce"))
                    {
                        dishes["Dipping sauce"]++;
                    }
                    else
                    {
                        dishes.Add("Dipping sauce", 1);
                    }
                    freshness.Pop();
                    ingredient.Dequeue();
                }
                else if (sum == 250)
                {
                    if (dishes.ContainsKey("Green salad"))
                    {
                        dishes["Green salad"]++;
                    }
                    else
                    {
                        dishes.Add("Green salad", 1);
                    }
                    freshness.Pop();
                    ingredient.Dequeue();
                }
                else if (sum == 300)
                {
                    if (dishes.ContainsKey("Chocolate cake"))
                    {
                        dishes["Chocolate cake"]++;
                    }
                    else
                    {
                        dishes.Add("Chocolate cake", 1);
                    }
                    freshness.Pop();
                    ingredient.Dequeue();
                }
                else if (sum == 400)
                {
                    if (dishes.ContainsKey("Lobster"))
                    {
                        dishes["Lobster"]++;
                    }
                    else
                    {
                        dishes.Add("Lobster", 1);
                    }
                    freshness.Pop();
                    ingredient.Dequeue();
                }
                else
                {
                    freshness.Pop();
                    ingredient.Dequeue();
                    ingredient.Enqueue(curringredient + 5);
                }
            }
            if (dishes.Count == 4)
            {
                Console.WriteLine("Applause! The judges are fascinated by your dishes!");
                if (ingredient.Count > 0)
                {
                    Console.WriteLine($"Ingredients left: {ingredient.Sum()}");
                }
                
                foreach (var item in dishes)
                {
                    Console.WriteLine($" # {item.Key} --> {item.Value}");
                }
            }
            else
            {
                Console.WriteLine("You were voted off. Better luck next year.");
                if (ingredient.Count > 0)
                {
                    Console.WriteLine($"Ingredients left: {ingredient.Sum()}");
                }
                
                foreach (var item in dishes)
                {
                    Console.WriteLine($" # {item.Key} --> {item.Value}");
                }
            }
        }
    }
}
