﻿using System;
using System.Linq;

namespace _02.Survivor
{
    internal class Program
    {
        private static char[][] field;
        static void Main(string[] args)
        {
            int n  = int.Parse(Console.ReadLine());
            field = new char[n][];
            int collectedTokens = 0;
            int oponentTokens = 0;
            int alltokens = 0;
            for (int i = 0; i < n; i++)
            {
                char[] line =  Console.ReadLine().Split(' ').Select(char.Parse).ToArray();
                field[i] = line;
                for (int j = 0; j < line.Length; j++)
                {
                    if (char.IsLetter(line[j]))
                    {
                        alltokens++;
                    }
                }
            }
            while (true)
            {
                string[] input = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray();
                string cmd = input[0];
                if (cmd.ToLower() == "gong")
                {
                    break;
                }
                int row = int.Parse(input[1]);
                int coll = int.Parse(input[2]);
                if (cmd == "Find")
                {
                    if (IsInside(row,coll))
                    {
                        if (char.IsLetter(field[row][coll]))
                        {
                            collectedTokens++;
                            alltokens--;
                            field[row][coll] = '-';
                        }
                    }
                }
                else if (cmd == "Opponent")
                {
                    string direction = input[3];
                    if (IsInside(row, coll))
                    {
                        if (char.IsLetter(field[row][coll]))
                        {
                            oponentTokens++;
                            alltokens--;
                            field[row][coll] = '-';
                        }
                        if (direction == "up")
                        {
                            for (int i = 0; i < 3; i++)
                            {
                                row--;
                                if (IsInside(row, coll))
                                {
                                    if (char.IsLetter(field[row][coll]))
                                    {
                                        oponentTokens++;
                                        alltokens--;
                                        field[row][coll] = '-';
                                    }
                                }
                            }
                        }
                        else if (direction == "down")
                        {
                            for (int i = 0; i < 3; i++)
                            {
                                row++;
                                if (IsInside(row, coll))
                                {
                                    if (char.IsLetter(field[row][coll]))
                                    {
                                        oponentTokens++;
                                        alltokens--;
                                        field[row][coll] = '-';
                                    }
                                }
                            }
                        }
                        else if (direction == "right")
                        {
                            for (int i = 0; i < 3; i++)
                            {
                                coll++;
                                if (IsInside(row, coll))
                                {
                                    if (char.IsLetter(field[row][coll]))
                                    {
                                        oponentTokens++;
                                        alltokens--;
                                        field[row][coll] = '-';
                                    }
                                }
                            }
                            
                        }
                        else if (direction == "left")
                        {
                            for (int i = 0; i < 3; i++)
                            {
                                coll--;
                                if (IsInside(row, coll))
                                {
                                    if (char.IsLetter(field[row][coll]))
                                    {
                                        oponentTokens++;
                                        alltokens--;
                                        field[row][coll] = '-';
                                    }
                                }
                            }
                        }
                    }
                }
                if (alltokens == 0)
                {
                    break;
                }
            }
            for (int i = 0; i < field.Length; i++)
            {
                Console.WriteLine(String.Join(" ", field[i]));
                
            }
            Console.WriteLine($"Collected tokens: {collectedTokens}");
            Console.WriteLine($"Opponent's tokens: {oponentTokens}");
        }
        static bool IsInside(int row,int coll)
        {
            return row >= 0 && coll >= 0 && row < field.GetLength(0) && coll < field[row].Length;
        }
    }
}
